__all__ = ["LinearNet", "fit_predict", "Trainer"]
__version__ = "0.2.0"

from .api import LinearNet, fit_predict, Trainer

